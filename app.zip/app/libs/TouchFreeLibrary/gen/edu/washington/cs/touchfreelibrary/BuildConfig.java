/** Automatically generated file. DO NOT MODIFY */
package edu.washington.cs.touchfreelibrary;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}